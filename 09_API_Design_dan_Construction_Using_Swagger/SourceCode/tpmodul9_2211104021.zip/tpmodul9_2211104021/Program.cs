using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Collections.Generic;

namespace tpmodul9_2211104021
{
    public class Mahasiswa
    {
        public string Nama { get; set; }
        public string Nim { get; set; }

        public Mahasiswa(string nama, string nim)
        {
            Nama = nama;
            Nim = nim;
        }
    }

    public class Program
    {
        public static List<Mahasiswa> daftarMahasiswa = new List<Mahasiswa>
        {
            new Mahasiswa("Wahyu Isnantia Qodri Ghozali", "2211104021"),
            new Mahasiswa("LeBron James", "1302000001"),
            new Mahasiswa("Stephen Curry", "1302000002")
        };

        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var app = builder.Build();

            app.MapGet("/", () => "Hello World!");

            // GET semua mahasiswa
            app.MapGet("/api/mahasiswa", () => daftarMahasiswa);

            // GET mahasiswa berdasarkan index
            app.MapGet("/api/mahasiswa/{index:int}", (int index) =>
            {
                if (index >= 0 && index < daftarMahasiswa.Count)
                {
                    return Results.Ok(daftarMahasiswa[index]);
                }
                return Results.NotFound("Index tidak ditemukan.");
            });

            // POST mahasiswa baru
            app.MapPost("/api/mahasiswa", (Mahasiswa mhs) =>
            {
                daftarMahasiswa.Add(mhs);
                return Results.Ok($"Mahasiswa {mhs.Nama} ditambahkan.");
            });

            // DELETE mahasiswa berdasarkan index
            app.MapDelete("/api/mahasiswa/{index:int}", (int index) =>
            {
                if (index >= 0 && index < daftarMahasiswa.Count)
                {
                    var deleted = daftarMahasiswa[index];
                    daftarMahasiswa.RemoveAt(index);
                    return Results.Ok($"Mahasiswa {deleted.Nama} dihapus.");
                }
                return Results.NotFound("Index tidak ditemukan.");
            });

            // PUT update mahasiswa berdasarkan index
            app.MapPut("/api/mahasiswa/{index:int}", (int index, Mahasiswa mhs) =>
            {
                if (index >= 0 && index < daftarMahasiswa.Count)
                {
                    daftarMahasiswa[index] = mhs;
                    return Results.Ok($"Mahasiswa di index {index} diupdate.");
                }
                return Results.NotFound("Index tidak ditemukan.");
            });


            app.Run();
        }
    }
}
