﻿using System;
using System.Diagnostics;
using System.Collections.Generic;

class SayaTubeVideo
{
    private int id;
    private string title;
    private int playCount;

    public SayaTubeVideo(string title)
    {
        Debug.Assert(!string.IsNullOrEmpty(title), "Judul video tidak boleh null atau kosong.");
        Debug.Assert(title.Length <= 200, "Judul video tidak boleh lebih dari 200 karakter.");

        this.id = new Random().Next(10000, 99999);
        this.title = title;
        this.playCount = 0;
    }

    public void IncreasePlayCount(int count)
    {
        Debug.Assert(count > 0 && count <= 25000000, "Penambahan play count tidak boleh lebih dari 25.000.000 dan harus lebih dari 0.");

        try
        {
            checked
            {
                playCount += count;
            }
        }
        catch (OverflowException)
        {
            Console.WriteLine("Error: Play count melebihi batas integer!");
        }
    }

    public void PrintVideoDetails()
    {
        Console.WriteLine($"ID: {id}");
        Console.WriteLine($"Title: {title}");
        Console.WriteLine($"Play Count: {playCount}");
        Console.WriteLine();
    }

    public int GetPlayCount()
    {
        return playCount;
    }

    public string GetTitle()
    {
        return title;
    }
}

class SayaTubeUser
{
    private int id;
    private string username;
    private List<SayaTubeVideo> uploadedVideos;

    public SayaTubeUser(string username)
    {
        Debug.Assert(!string.IsNullOrEmpty(username), "Username tidak boleh null atau kosong.");
        Debug.Assert(username.Length <= 100, "Username tidak boleh lebih dari 100 karakter.");

        this.id = new Random().Next(10000, 99999);
        this.username = username;
        this.uploadedVideos = new List<SayaTubeVideo>();
    }

    public void AddVideo(SayaTubeVideo video)
    {
        Debug.Assert(video != null, "Video tidak boleh null.");
        Debug.Assert(video.GetPlayCount() < int.MaxValue, "Play count video tidak boleh melebihi batas integer.");

        uploadedVideos.Add(video);
    }

    public void PrintAllVideoPlaycount()
    {
        Console.WriteLine($"User: {username}");

        int maxVideosToPrint = Math.Min(uploadedVideos.Count, 8);
        for (int i = 0; i < maxVideosToPrint; i++)
        {
            Console.WriteLine($"Video {i + 1}: {uploadedVideos[i].GetTitle()} - {uploadedVideos[i].GetPlayCount()} views");
        }
    }

    public List<SayaTubeVideo> GetUploadedVideos()
    {
        return uploadedVideos;
    }
}

class Program
{
    static void Main(string[] args)
    {
        SayaTubeUser user = new SayaTubeUser("Wahyu Isnantia Qodri Ghozali");

        List<string> videoTitles = new List<string>
        {
            "Oppenheimer",
            "Dune",
            "Pacific Rim",
            "Venom",
            "Deadpool",
            "Harry Potter",
            "Game of Thrones",
            "Narnia"
        };

        foreach (var title in videoTitles)
        {
            SayaTubeVideo video = new SayaTubeVideo($"Review film {title} oleh Wahyu Isnantia Qodri Ghozali");
            user.AddVideo(video);
        }

        user.PrintAllVideoPlaycount();

        // Mengakses video melalui method GetUploadedVideos()
        var videos = user.GetUploadedVideos();

        // Test valid play count increment
        Console.WriteLine("\nMenambahkan play count...");
        videos[0].IncreasePlayCount(1000000);
        videos[0].PrintVideoDetails();

        // Test overflow exception
        Console.WriteLine("\nMenguji overflow play count...");
        for (int i = 0; i < 10; i++)
        {
            videos[0].IncreasePlayCount(25000000);
        }

        user.PrintAllVideoPlaycount();
    }
}
