﻿using System;
using System.Diagnostics;

class MathHelper
{
    static double DivideSafely(double numerator, double denominator)
    {
        if (denominator == 0)
        {
            throw new DivideByZeroException("Pembagian dengan nol tidak diperbolehkan.");
        }

        Debug.Assert(denominator != 0, "Denominator tidak boleh nol.");
        return numerator / denominator;
    }

    static void Main()
    {
        double num = 20, denom = 0;
        double quotient;

        try
        {
            if (denom == 0)
            {
                throw new DivideByZeroException("Nilai penyebut tidak boleh nol.");
            }

            quotient = DivideSafely(num, denom);
            Console.WriteLine("Hasil pembagian: " + quotient);
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("Terjadi kesalahan: " + ex.Message);
        }
    }
}
